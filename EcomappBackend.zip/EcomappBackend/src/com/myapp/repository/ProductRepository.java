package com.myapp.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.myapp.dao.ProductDAO;
import com.myapp.model.Product;
import com.myapp.utility.DbConnect;

public class ProductRepository implements ProductDAO {

	DbConnect db;
	Connection con;
	
	public ProductRepository() {

        db = new DbConnect();
        con = db.getConnection();
	}

	@Override
	public boolean addProduct(Product product) {
		Connection con=null;
		try {
		  con = db.getConnection();
			System.out.println("add called from product");
			//db = new DbConnect();
			//con = db.getConnection();
			PreparedStatement stmt = con.prepareStatement(
					"INSERT INTO products (Productid, ProdName,ProdPrice)"
							+ " values (?, ?, ?)");
			stmt.setInt(1, product.getProductId());
			stmt.setString(2, product.getProductName());
			stmt.setFloat(3, product.getProductPrice());
			stmt.executeUpdate();
			con.close();
			System.out.println("record added");
			return true;
		} catch (SQLException e) {
			System.out.println(e);
		}finally {
			
		}
		
		return false;
	}

	@Override
	public boolean deleteProduct(int productId) {
		// TODO Auto-generated method stub
		return false;
	}

	
}
