package com.myapp.test;
import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;

import com.myapp.model.Product;
import com.myapp.repository.ProductRepository;
import com.myapp.repository.UserRepository;

public class ProductRepoTest {

	ProductRepository product;
	
	@Before
    public void setUp() {
		product = new ProductRepository();
    }
	
	@Test
	public void testDBConnection() {
		String url= "jdbc:oracle:thin:localhost:1521:xe" ;
		try {
			Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe", "HR", "password");
			System.out.println("We are connected to the db");
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT productid,prodname FROM hr.products");
			while (rs.next()) {
				String prodid = rs.getString("productid");
				String prodname = rs.getString("prodname");
				System.out.println(prodid + " " + prodname);
				}			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	
	@Test
	public void addProductTest() {
		ProductRepository productrepository = new ProductRepository();
		//test data
		Product product = new Product();
		product.setProductId(7777);
		product.setProductName("joeno");
		product.setProductPrice(224.25f);
		assertEquals("Failed to add the product!", true, productrepository.addProduct(product));
		
	}
	
	@AfterEach
	void tearDown() throws Exception {
	}
	
	
}
